function Qfine = QvalueManufAdjuster(Q,C,f)
    Qfine = Q;
end
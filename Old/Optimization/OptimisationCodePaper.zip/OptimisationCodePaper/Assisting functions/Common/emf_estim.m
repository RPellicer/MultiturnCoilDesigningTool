%%from eq 15 Hould 1979

function emf = emf_estim(freq,B1,M_0,Vol)

    emf = 2*pi*freq*B1*M_0*Vol; % = omega*B1*M_0*Vol;

end
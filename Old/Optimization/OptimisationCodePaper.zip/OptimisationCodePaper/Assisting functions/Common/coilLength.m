function l=coilLength(rc)

l=sum(2*pi*rc);

end
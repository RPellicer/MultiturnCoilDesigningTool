% Calculates the area of a multiturn coil

function areaT = areaTot(r)
    areaT = sum(pi.*(r.^2)); %
end
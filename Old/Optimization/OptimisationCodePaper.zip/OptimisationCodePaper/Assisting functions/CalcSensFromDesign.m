% AmplMode=> 
%  0 = Non-tuned
%  1 = Tuned
function [s,Probe] = CalcSensFromDesign(NrLoopsPerLayer,NrLayers,OutWireDiam,CoopDiam, AmplMode)
    run('C:\Users\s4370509\Documents\MATLAB\MultiturnDetector\Optimization\setGlobalVariables.m')
    visu =1;
    tProbe.Coil.N_v = NrLoopsPerLayer;
    tProbe.Coil.N_l = NrLayers;
    tProbe.Coil.do = OutWireDiam;    
    tProbe.Coil.di = CoopDiam;
    % Set other needed variables
    tProbe.Coil.Rin = tProbe.Coil.Rout_glob - tProbe.Coil.N_l*tProbe.Coil.do;
    percInsul = 0.99;
    switch AmplMode
        case 0 % Non-tuned
            if (tProbe.Coil.do*percInsul) <= tProbe.Coil.di
                tProbe.Coil.PenalyzeScaling = tProbe.Coil.PenalyzeScaling*(1+ 5*((1/(1-percInsul))*((tProbe.Coil.di-tProbe.Coil.do*percInsul)/tProbe.Coil.di))); % The second part makes the sensitivity 5 times worse when do=di. It can be adjusted
            end
            [s,Probe] = sensitivityI2V(tProbe,visu);
        otherwise % Tuned
            if (tProbe.Coil.do*percInsul) <= tProbe.Coil.di
                tProbe.Coil.PenalyzeScaling = tProbe.Coil.PenalyzeScaling*(1+ 5*((1/(1-percInsul))*((tProbe.Coil.di-tProbe.Coil.do*percInsul)/tProbe.Coil.di))); % The second part makes the sensitivity 5 times worse when do=di. It can be adjusted
            end
            [s,Probe] = sensTunedLinv(tProbe,visu);
    end
end
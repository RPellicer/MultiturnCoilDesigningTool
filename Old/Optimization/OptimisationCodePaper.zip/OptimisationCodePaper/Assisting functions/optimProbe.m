classdef optimProbe
    %OPTIMPROB Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        Type
        Coil
        Amp
        MatchNetw
        Sens
        Freqs
    end
    
    methods
    end
    
end

